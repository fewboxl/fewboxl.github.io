# FewBox PackingTable
# fewbox-uninstall.sh
# $1 - Namespace
RED=`tput setaf 1`
GREEN=`tput setaf 2`
YELLOW=`tput setaf 3`
NC=`tput sgr0`
echo "${YELLOW}Uninstall FewBox PackingTable${NC}, any suggestion please contact support@fewbox.com!"
if  [ ! -n "$1" ] ;then
    echo "Use default namespace fewbox-system"
    NAMESPACE="fewbox-system"
else
    echo "Use namespace $1"
    NAMESPACE=$1
fi

kubectl delete ClusterRoleBinding fewbox
kubectl delete Deployment packingtable -n $NAMESPACE
kubectl delete ConfigMap packingtable -n $NAMESPACE
kubectl delete ServiceAccount fewbox -n $NAMESPACE
kubectl delete CustomResourceDefinition packingtables.fewbox.com
echo "${GREEN}Uninstall FewBox PackingTable finished!${NC}"
# kubectl delete Namespace $NAMESPACE
