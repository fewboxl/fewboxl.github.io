# Let's Encrypt (https://letsencrypt.org/)
# Cerbot (https://certbot.eff.org/)

# Open SSL (CA)
```shell
# Generate SSL private key with password (fewbox-pw.key)
openssl genrsa -des3 -out fewbox-pw.key 2048
# View private key with password
openssl rsa -text -in fewbox-pw.key
# View private key with password
cat fewbox-pw.key
# Generate CSR (fewbox.csr) Certificate Signing Request
openssl req -new -key fewbox-pw.key -out fewbox.csr
# View CSR
openssl req -text -in fewbox.csr -noout
# Generate CRT (fewbox.crt) Certificate
openssl x509 -req -days 365 -in fewbox.csr -signkey fewbox-pw.key -out fewbox.crt
# Generate SSL private key
openssl rsa -in fewbox-pw.key -out fewbox.key
```