# Install Server
```shell
yum -y install nfs-utils rpcbind
mkdir -p /data/k8s
chmod 755 /data/k8s
vi /etc/exports
# /etc/exports
# /data/k8s 192.168.1.0/24(rw,sync,no_root_squash) // /data/k8s *(rw,sync,no_root_squash)
curl -v telnet://192.168.1.38:2049
```
## Start
```shell
systemctl enable rpcbind
systemctl enable nfs
systemctl start rpcbind
systemctl start nfs
rpcinfo -p
exportfs -r
exportfs
```
# Install Client
```shell
yum install nfs-common nfs-utils -y
```
# Mount NFS
```shell
mount -t nfs 192.168.1.38:/NFS/k8s /mount/nfs # Master and Worker Nodes, All point to NFS Server.
# mount -t nfs 192.168.1.38:/data/k8s /mount/nfs # Master and Worker Nodes, All point to NFS Server.
# mount -t nfs 192.168.1.38:/NFS/nginx /mount/nfs
curl -v telnet://192.168.1.38:2049
umount -f -l /mount/data/k8s
```
# **Kubernetes**
```shell
# IMPORTANT!!! Need to install in the master(optional) and worker node.
yum install nfs-utils
```
**NFS issue**
https://github.com/kubernetes-sigs/nfs-subdir-external-provisioner/issues/25

Using Kubernetes v1.20.0, getting "unexpected error getting claim reference: selfLink was empty, can't make reference"

quay.io/external_storage/nfs-client-provisioner:latest

gcr.io/k8s-staging-sig-storage/nfs-subdir-external-provisioner:v4.0.0
