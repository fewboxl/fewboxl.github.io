```shell
# 查看状态
systemctl status firewalld
# 重启
firewall-cmd --reload
# 开机启动
systemctl enable firewalld
# 禁用开机启动
sytemctl disable firewalld
# 启用
systemctl start firewalld 
# 停用
systemctl stop firewalld
# 查看区域
firewall-cmd --get-active-zones
firewall-cmd --get-zone-of-interface=enp0s3
# 查看拒绝包状态
firewall-cmd --query-panic
# 拒绝所有包
firewall-cmd --panic-on
# 取消拒绝所有包
firewall-cmd --panic-off
# 查看端口
firewall-cmd --zone=public --list-ports
# 打开端口
firewall-cmd --zone=public --add-port=80/tcp --permanent
firewall-cmd --reload
# 其他
# firewall-cmd --zone=public --add-interface=eth0(永久生效再加上 --permanent 然后reload防火墙)
# firewall-cmd --set-default-zone=public(立即生效，无需重启)
# firewall-cmd --reload或firewall-cmd --complete-reload(两者的区别就是第一个无需断开连接，就是firewalld特性之一动态
# 添加规则，第二个需要断开连接，类似重启服务)

```
