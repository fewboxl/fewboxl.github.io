# VirtualBox
网络
```shell
cd /etc/sysconfig/network-scripts/
vi ifcfg-enp0s3
systemctl restart network
```

```shell
# Need to change
BOOTPROTO="static"
IPADDR=192.168.1.111
NETMASK=255.255.255.0
GATEWAY=192.168.1.1
DNS1=114.114.114.114
```

```shell
yum update
yum install net-tools -y
```
