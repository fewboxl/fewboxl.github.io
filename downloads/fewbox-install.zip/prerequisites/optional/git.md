# Local View
```shell
git tag
```
# Remote View
```shell
git ls-remote --tag
```
# Local Add
```shell
git tag v1
```
# Remote Add
```shell
git push origin v1 
```
# Local Delete
```shell
git tag-d v1
```
# Remote Delete
```shell
git push origin -d v1
```