# 优化
```sh
k edit cm istio-sidecar-injector -n istio-system
# Change the requests as following json
k delete po istiod-64d75d6b98-kg7x4 -n istio-system
```
```json
"proxy": {
          "autoInject": "enabled",
          "clusterDomain": "cluster.local",
          "componentLogLevel": "misc:error",
          "enableCoreDump": false,
          "excludeIPRanges": "",
          "excludeInboundPorts": "",
          "excludeOutboundPorts": "",
          "holdApplicationUntilProxyStarts": false,
          "image": "proxyv2",
          "includeIPRanges": "*",
          "logLevel": "warning",
          "privileged": false,
          "readinessFailureThreshold": 30,
          "readinessInitialDelaySeconds": 1,
          "readinessPeriodSeconds": 2,
          "resources": {
            "limits": {
              "cpu": "2000m",
              "memory": "1024Mi"
            },
            "requests": {
              "cpu": "100m", //need to change
              "memory": "128Mi" // need to change
            }
          },
          "statusPort": 15020,
          "tracer": "zipkin"
        }
```
# Port
|Port|Protocol|Used by	Description
|:----:|:----:|:----:|
|15000	|TCP	|Envoy	Envoy admin port (commands/diagnostics)
|15001	|TCP	|Envoy	Envoy Outbound
|15006	|TCP	|Envoy	Envoy Inbound
|15020	|HTTP	|Envoy	Istio agent Prometheus telemetry
|15021	|HTTP	|Envoy	Health checks
|15090	|HTTP	|Envoy	Envoy Prometheus telemetry
|15010	|GRPC	|Istiod	XDS and CA services (plaintext)
|15012	|GRPC	|Istiod	XDS and CA services (TLS)
|8080	|HTTP	|Istiod	Debug interface
|443	|HTTPS	|Istiod	Webhooks
|15014	|HTTP	|Mixer, Istiod	Control plane monitoring
|15443	|TLS	|Ingress and Egress Gateways	SNI
|9090	|HTTP	|Prometheus	Prometheus
|42422	|TCP	|Mixer	Telemetry - Prometheus
|15004	|HTTP	|Mixer, Pilot	Policy/Telemetry - mTLS
|9091	|HTTP	|Mixer	Policy/Telemetry
# Install
```Shell
curl -L https://istio.io/downloadIstio | sh -
istioctl install
# istioctl install --set profile=demo -y
# istioctl install --set values.global.controlPlaneSecurityEnabled=true
# istioctl install --set components.telemetry.enabled=false
```
# Addon
```Shell
# samples/addons
kubectl apply -f https://raw.githubusercontent.com/istio/istio/release-1.15/samples/addons/prometheus.yaml
kubectl apply -f https://raw.githubusercontent.com/istio/istio/release-1.15/samples/addons/grafana.yaml
kubectl apply -f https://raw.githubusercontent.com/istio/istio/release-1.15/samples/addons/jaeger.yaml
kubectl apply -f https://raw.githubusercontent.com/istio/istio/release-1.15/samples/addons/kiali.yaml
```
# Chart
```Shell
# istioctl install --charts=manifests/
```
# Profile
```Shell
# istioctl install --set profile=demo
istioctl profile list
istioctl profile dump default
istioctl profile diff default demo
```
# Verify
```Shell
istioctl manifest generate > $HOME/generated-manifest.yaml
istioctl verify-install -f $HOME/generated-manifest.yaml
```
# Uninstall
```Shell
# All
istioctl x uninstall --purge
# Control Panel
istioctl x uninstall <your original installation options>
istioctl manifest generate <your original installation options> | kubectl delete -f -
# Namespace
kubectl delete namespace istio-system
# 
```

# Error
## JWT Issue
```shell
2020-03-25T14:15:56.502801Z     info    JWT policy is first-party-jwt
2020-03-25T14:15:56.502985Z     warn    Missing JWT token, can't use in process SDS /var/run/secrets/kubernetes.io/serviceaccount/tokenstat /var/run/secrets/kubernetes.io/serviceaccount/token: no such file or directory
2020-03-25T14:15:56.503001Z     fatal   Missing JWT, can't authenticate with control plane. Try using plain text (15010)
```

deployment > template > spec

automountServiceAccountToken: true

# Example
## Accessing External Services
```shell
kubectl apply -f samples/sleep/sleep.yaml
kubectl apply -f <(istioctl kube-inject -f samples/sleep/sleep.yaml)
export SOURCE_POD=$(kubectl get pod -l app=sleep -o jsonpath={.items..metadata.name})
istioctl install --set meshConfig.outboundTrafficPolicy.mode=ALLOW_ANY
istioctl install --set meshConfig.outboundTrafficPolicy.mode=REGISTRY_ONLY
kubectl get configmap istio -n istio-system -o yaml | grep -o "mode: ALLOW_ANY" | uniq
# Http
kubectl exec -it $SOURCE_POD -c sleep -- curl http://httpbin.org/headers
kubectl apply -f - <<EOF
apiVersion: networking.istio.io/v1alpha3
kind: ServiceEntry
metadata:
  name: httpbin-ext
spec:
  hosts:
  - httpbin.org
  ports:
  - number: 80
    name: http
    protocol: HTTP
  resolution: DNS
  location: MESH_EXTERNAL
EOF
kubectl exec -it $SOURCE_POD -c sleep -- curl http://httpbin.org/headers
kubectl logs $SOURCE_POD -c istio-proxy | tail
# Https
kubectl exec -it $SOURCE_POD -c sleep -- curl -I https://www.baidu.com | grep  "HTTP/"
kubectl apply -f - <<EOF
apiVersion: networking.istio.io/v1alpha3
kind: ServiceEntry
metadata:
  name: baidu
spec:
  hosts:
  - www.baidu.com
  ports:
  - number: 443
    name: https
    protocol: HTTPS
  resolution: DNS
  location: MESH_EXTERNAL
EOF
kubectl exec -it $SOURCE_POD -c sleep -- curl -I https://www.baidu.com | grep  "HTTP/"
kubectl logs $SOURCE_POD -c istio-proxy | tail
# Manage traffic
kubectl exec -it $SOURCE_POD -c sleep -- time curl -o /dev/null -s -w "%{http_code}\n" http://httpbin.org/delay/5
kubectl apply -f - <<EOF
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: httpbin-ext
spec:
  hosts:
    - httpbin.org
  http:
  - timeout: 3s
    route:
      - destination:
          host: httpbin.org
        weight: 100
EOF
kubectl exec -it $SOURCE_POD -c sleep -- time curl -o /dev/null -s -w "%{http_code}\n" http://httpbin.org/delay/5
# Clear
kubectl delete serviceentry httpbin-ext baidu
kubectl delete virtualservice httpbin-ext --ignore-not-found=true
kubectl delete -f samples/sleep/sleep.yaml

```
# Global Mesh Options (istioctl install --set XX=YY)
https://istio.io/latest/docs/reference/config/istio.mesh.v1alpha1/#MeshConfig-OutboundTrafficPolicy-Mode
