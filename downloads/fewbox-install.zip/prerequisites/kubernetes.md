# Edit Repo File
```shell
vi /etc/yum.repos.d/kubernetes.repo
```
## 1.1 GPG Check
```shell
[kubernetes] 
name=Kubernetes 
baseurl=https://mirrors.aliyun.com/kubernetes/yum/repos/kubernetes-el7-x86_64 
enabled=1 
gpgcheck=1 
repo_gpgcheck=1 
gpgkey=https://mirrors.aliyun.com/kubernetes/yum/doc/yum-key.gpg 
```
## 1.2 No GPG Check
```shell
[kubernetes] 
name=Kubernetes 
baseurl=https://mirrors.aliyun.com/kubernetes/yum/repos/kubernetes-el7-x86_64 
enabled=1 
gpgcheck=0
```
# Install Kubeadm
```shell
# kubelet
# yum --showduplicates list kubelet
yum remove kubelet
yum install kubelet-1.19.16-0

yum install kubeadm-1.19.16
```

# Install Docker
```shell
# Remove old version
yum remove docker-client \
docker-client-latest \
docker-common \
docker-latest \
docker-latest-logrotate \
docker-logrotate \
docker-selinux \
docker-engine-selinux \
docker-engine
# Install
yum install yum-utils
yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
yum install docker-ce
systemctl enable docker && systemctl start docker
```
```shell
# **Note: NEEDED**
cat > /etc/docker/daemon.json <<EOF
{
  "exec-opts": ["native.cgroupdriver=systemd"],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "100m"
  },
  "storage-driver": "overlay2",
  "registry-mirrors": [
    "https://hub-mirror.c.163.com",
    "https://mirror.baidubce.com"
  ],
  "insecure-registries": ["192.168.1.38:5000"]
}
EOF
#
docker info | grep Cgroup
```
# Download Kubernetes Image
```shell
# sync.sh (Master)
echo ""
#Init Parameters
MY_REGISTRY=registry.cn-hangzhou.aliyuncs.com/google_containers
#MY_REGISTRY=mirrorgcrio
VERSION=$(kubeadm config images list | grep -m1 kube | awk -F: '{print $2}')
ETCD_VERSION=$(kubeadm config images list | grep -m1 etcd | awk -F: '{print $2}')
PAUSE_VERSION=$(kubeadm config images list | grep -m1 pause | awk -F: '{print $2}')
COREDNS_VERSION=$(kubeadm config images list | grep -m1 coredns | awk -F: '{print $2}')

echo "=========================================================="
echo "FewBox Pull Kubernetes "$VERSION" Images from "$MY_REGISTRY" ......"
echo "=========================================================="
echo ""
kubeadm config images list

# Pull Image
docker pull ${MY_REGISTRY}/kube-apiserver:$VERSION
docker pull ${MY_REGISTRY}/kube-controller-manager:$VERSION
docker pull ${MY_REGISTRY}/kube-scheduler:$VERSION
docker pull ${MY_REGISTRY}/kube-proxy:$VERSION
docker pull ${MY_REGISTRY}/etcd:$ETCD_VERSION
docker pull ${MY_REGISTRY}/pause:$PAUSE_VERSION
docker pull ${MY_REGISTRY}/coredns:$COREDNS_VERSION

# Add Tag
docker tag ${MY_REGISTRY}/kube-apiserver:$VERSION k8s.gcr.io/kube-apiserver:$VERSION
docker tag ${MY_REGISTRY}/kube-scheduler:$VERSION k8s.gcr.io/kube-scheduler:$VERSION
docker tag ${MY_REGISTRY}/kube-controller-manager:$VERSION k8s.gcr.io/kube-controller-manager:$VERSION
docker tag ${MY_REGISTRY}/kube-proxy:$VERSION k8s.gcr.io/kube-proxy:$VERSION
docker tag ${MY_REGISTRY}/etcd:$ETCD_VERSION k8s.gcr.io/etcd:$ETCD_VERSION
docker tag ${MY_REGISTRY}/pause:$PAUSE_VERSION k8s.gcr.io/pause:$PAUSE_VERSION
docker tag ${MY_REGISTRY}/coredns:$COREDNS_VERSION k8s.gcr.io/coredns:$COREDNS_VERSION

echo ""
echo "=========================================================="
echo "FewBox Pull Kubernetes "$VERSION" Images FINISHED."
echo "=========================================================="

echo ""
```
```shell
# sync.sh (Worker)
echo ""
#Init Parameters
MY_REGISTRY=registry.cn-hangzhou.aliyuncs.com/google_containers
#MY_REGISTRY=mirrorgcrio
VERSION=$(kubeadm config images list | grep -m1 kube | awk -F: '{print $2}')
ETCD_VERSION=$(kubeadm config images list | grep -m1 etcd | awk -F: '{print $2}')
PAUSE_VERSION=$(kubeadm config images list | grep -m1 pause | awk -F: '{print $2}')
COREDNS_VERSION=$(kubeadm config images list | grep -m1 coredns | awk -F: '{print $2}')

echo "=========================================================="
echo "FewBox Pull Kubernetes "$VERSION" Images from "$MY_REGISTRY" ......"
echo "=========================================================="
echo ""
kubeadm config images list

# Pull Image
docker pull ${MY_REGISTRY}/kube-proxy:$VERSION
docker pull ${MY_REGISTRY}/pause:$PAUSE_VERSION
docker pull ${MY_REGISTRY}/coredns:$COREDNS_VERSION

# Add Tag
docker tag ${MY_REGISTRY}/kube-proxy:$VERSION k8s.gcr.io/kube-proxy:$VERSION
docker tag ${MY_REGISTRY}/pause:$PAUSE_VERSION k8s.gcr.io/pause:$PAUSE_VERSION
docker tag ${MY_REGISTRY}/coredns:$COREDNS_VERSION k8s.gcr.io/coredns:$COREDNS_VERSION

echo ""
echo "=========================================================="
echo "FewBox Pull Kubernetes "$VERSION" Images FINISHED."
echo "=========================================================="

echo ""
```
# Setting Network
```shell
# Firewall
systemctl stop firewalld
systemctl disable firewalld
# Set SELinux in permissive mode (effectively disabling it)
sudo setenforce 0
sudo sed -i 's/^SELINUX=enforcing$/SELINUX=permissive/' /etc/selinux/config
swapoff -a
sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab
# Bridge
cat <<EOF | sudo tee /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
EOF
sysctl --system
```
# Start Agent (Kubelet)
```shell
systemctl daemon-reload
systemctl enable kubelet && systemctl restart kubelet
journalctl -xefu kubelet
```

# Install Master
```shell
# Multiple Eth need --apiserver-advertise-address
kubeadm init --pod-network-cidr=10.244.0.0/16 --apiserver-advertise-address=xxx.xxx.xxx.xxx --apiserver-cert-extra-sans=xxx.xxx.xxx.xxx --ignore-preflight-errors=NumCPU --kubernetes-version=1.19.16 
```

# Install Flannel
```shell
kubectl apply -f https://raw.githubusercontent.com/flannel-io/flannel/master/Documentation/kube-flannel.yml
#或者
wget https://raw.githubusercontent.com/flannel-io/flannel/master/Documentation/kube-flannel.yml
vi kube-flannel.yml # ☢️❗️❗️❗️☢️Change 10.244.0.0/16
kubectl apply -f kube-flannel.yml
```

# Install Calico
```shell
# https://projectcalico.docs.tigera.io/getting-started/kubernetes/self-managed-onprem/onpremises#install-calico
curl https://docs.projectcalico.org/manifests/calico.yaml -O
# ☢️❗️❗️❗️☢️Change CALICO_IPV4POOL_CIDR same as pod cidr (kubectl cluster-info dump | grep -m 1 cluster-cidr)
kubectl create -f calico.yaml
curl -O -L https://github.com/projectcalico/calicoctl/releases/download/v3.15.1/calicoctl
chmod +x calicoctl
mv calicoctl /usr/local/bin
export CALICO_DATASTORE_TYPE=kubernetes
export CALICO_KUBECONFIG=/etc/kubernetes/admin.conf
calicoctl get ippool
calicoctl get node
calicoctl node status
```
# Check Status
```shell
k get cs
# scheduler            Unhealthy   Get "http://127.0.0.1:10251/healthz": dial tcp 127.0.0.1:10251: connect: connection refused   
# controller-manager   Unhealthy   Get "http://127.0.0.1:10252/healthz": dial tcp 127.0.0.1:10252: connect: connection refused
# Solution: need to remove "--port=0" in kube-controller-manager.yaml  kube-scheduler.yaml /etc/kubernetes/manifests 
systemctl restart kubelet.service
```
# Install Worker
```shell
kubeadm token create --print-join-command
kubeadm join 172.17.0.1:6443 --token vv4prq.ezm481v2k0oa0273 --discovery-token-ca-cert-hash sha256:bd34337dcab22ce02049d1f98dc73a96729f1a3b9c9d80a3d76e175af1db4e21
```
# Start
```shell
# start.sh
export KUBECONFIG=/etc/kubernetes/admin.conf
alias k=kubectl  #~/.bashrc
source <(kubectl completion bash)
source <(kubectl completion bash | sed s/kubectl/k/g)
alias kcd='kubectl config set-context $(kubectl config current-context) --namespace'
export CALICO_DATASTORE_TYPE=kubernetes
export CALICO_KUBECONFIG=/etc/kubernetes/admin.conf
# export PATH=$PATH:/root/istio-1.6.2/bin/
```
```shell
# Enable tab help
yum -y install bash-completion
bash /usr/share/bash-completion/bash_completion
bash
```

--------------------------------

# Useful kubectl command
```shell
kubectl describe node //资源不足查看
kubectl describe node |grep -E '((Name|Roles):\s{6,})|(\s+(memory|cpu)\s+[0-9]+\w{0,2}.+%\))'
```

# Clear Calico
```shell
modprobe -r ipip
cd /etc/cni/net.d/
kubectl delete -f calico.yaml
```
# Clear CNI
```shell
/var/lib/cni
/etc/cni/net.d #Network issue need to clean.
ip link delete cni0 # Sandbox
```
# Delete Node
```shell
kubectl drain <node name> --delete-local-data --force --ignore-daemonsets
kubeadm reset
cd /etc/cni/net.d/
# remove /etc/cni/net.d/
lsof -i :6443|grep -v "PID"|awk '{print "kill -9",$2}'|sh
iptables -F && iptables -t nat -F && iptables -t mangle -F && iptables -X
ipvsadm -C
kubectl delete node <node name>
```

# Enable Master Deploy
```shell
kubectl taint nodes --all node-role.kubernetes.io/master-
```

# Intall Metric
```shell
docker pull bitnami/metrics-server:0.6.1
docker tag bitnami/metrics-server:0.6.1 k8s.gcr.io/metrics-server/metrics-server:v0.6.1
kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml
```
## Diable Security
```yaml
spec:
      containers:
      - args:
        - --cert-dir=/tmp
        - --secure-port=4443
        command:
        - /metrics-server
        - --kubelet-insecure-tls=true
        - --kubelet-preferred-address-types=InternalIP
        image: k8s.gcr.io/metrics-server/metrics-server:v0.3.7
```
```yaml
args:
- --cert-dir=/tmp
- --secure-port=4443
- --kubelet-preferred-address-types=InternalIP,ExternalIP,Hostname
- --kubelet-use-node-status-port
- --kubelet-insecure-tls # Add this line (New Version).
```
## Verify
```shell
kubectl top node
kubectl top pod
```
