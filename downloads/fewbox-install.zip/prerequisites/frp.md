> https://github.com/fatedier/frp


# Download
```shell
# https://github.com/fatedier/frp/releases
# amd64
wget https://github.com/fatedier/frp/releases/download/v0.44.0/frp_0.44.0_linux_amd64.tar.gz
```
# Server
## 云主机 frps.ini
```ini
# https://gofrp.org/docs/examples/ frps.ini
[common]
bind_port = 7000
vhost_http_port = 8080
vhost_https_port = 8081
log_file = console
dashboard_port = 7500
dashboard_user = fewbox
dashboard_pwd = {Your Pwd}
token = {Your Token}
max_pool_count = 50
dashboard_addr = 0.0.0.0
dashboard_port = 7500
dashboard_user = fewbox
dashboard_pwd = {Your Pwd}
```
```shell
vi /etc/systemd/system/frps.service
```
```ini
[Unit]
Description = frp server
After = network.target syslog.target
Wants = network.target

[Service]
Type = simple
ExecStart = /path/to/frps -c /path/to/frps.ini

[Install]
WantedBy = multi-user.target
```
```shell
systemctl start frps
systemctl stop frps
systemctl restart frps
systemctl status frps
systemctl enable frps
```
# Client
## 威联通 frpc.ini
```ini
[common]
server_addr = 82.157.243.144
server_port = 7000
token = {Your Token}

[web]
type = http
local_ip = 192.168.1.38
local_port = 5000
custom_domains = *.fewbox.com
```
> docker pull fatedier/frpc 镜像
- 命令：-c /frpc/frpc.ini
- 进入点：/usr/bin/frpc
- 共享文件夹：/DevOps/frpc  /frpc
