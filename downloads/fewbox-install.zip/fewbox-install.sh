#!/bin/bash
# FewBox PackingTable
# fewbox-install.sh
# $1 - Namespace
RED=`tput setaf 1`
GREEN=`tput setaf 2`
YELLOW=`tput setaf 3`
NC=`tput sgr0`
echo "Wellcome to use FewBox PackingTable"
# Registry Image
echo "${YELLOW}Please input registry(default docker hub):${NC}"
read
if  [ -z $REPLY ] ;then
    echo "${GREEN}Official Docker Hub${NC}"
    PACKINGTABLEIMAGE="fewbox/packingtable:v1"
else
    echo "${GREEN}Use Registry $REPLY${NC}"
    PACKINGTABLEIMAGE="$REPLY/fewbox/packingtable:v1"
fi
unset REPLY
echo ""
echo ""
echo "${YELLOW}Please input namespace(default fewbox-system):${NC}"
read
# Namespace
if  [ ! -n "$1" ] ;then
    echo "${GREEN}Use default namespace fewbox-system${NC}"
    NAMESPACE="fewbox-system"
else
    echo "${GREEN}Use namespace $1${NC}"
    NAMESPACE=$1
fi
echo ""
echo ""
# Domain Name
echo "${YELLOW}Please input Domain Name(default fewbox.com):${NC}"
read
if  [ -z $REPLY ] ;then
    echo "${GREEN}Use default domain name fewbox.com${NC}"
    DOMAINNAME="fewbox.com"
else
    echo "${GREEN}Use domain name $REPLY${NC}"
    DOMAINNAME=$REPLY
fi
unset REPLY
echo ""
echo ""
# Nfs Server
while [[ -z $REPLY ]]
do
    echo "${YELLOW}Please input Nfs Server:${NC} (E.G 192.168.1.38)"
    read
    if  [ -z $REPLY ] ;then
        echo "${RED}Empty${NC}"
    else
        echo "${GREEN}Use Nfs Server $REPLY${NC}"
        NFSSERVER=$REPLY
    fi
done
unset REPLY
echo ""
echo ""
# Nfs Path
while [[ -z $REPLY ]]
do
    echo "${YELLOW}Please input Nfs Path:${NC} (E.G /NFS/k8s)"
    read
    if  [ -z $REPLY ] ;then
        echo "${RED}Empty${NC}"
    else
        echo "${GREEN}Use Nfs Path $REPLY${NC}"
        NFSPATH=$REPLY
    fi
done
unset REPLY
echo ""
echo ""

cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: Namespace
metadata:
  annotations:
    brand: fewbox
  labels:
    brand: fewbox
  name: $NAMESPACE
---
apiVersion: v1
kind: Namespace
metadata:
  annotations:
    brand: fewbox
  labels:
    brand: fewbox
  name: fewbox
---
apiVersion: v1
kind: ServiceAccount
metadata:
  annotations:
    brand: fewbox
  labels:
    brand: fewbox
  name: fewbox
  namespace: $NAMESPACE
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  annotations:
    brand: fewbox
  labels:
    brand: fewbox
  name: fewbox
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: cluster-admin
subjects:
- kind: ServiceAccount
  name: fewbox
  namespace: $NAMESPACE
- kind: ServiceAccount
  name: fewbox
  namespace: fewbox
---
# FewBox PackingTable Engine Config
apiVersion: v1
kind: ConfigMap
metadata:
  name: packingtable
  namespace: $NAMESPACE
data:
  packingtable: |-
    {
      "Logging": {
        "LogLevel": {
          "Default": "Debug"
        }
      },
      "DevOps": {
        "Endpoints": {
          "K8SEndpoint": {
            "Protocol": "https",
            "Host": "kubernetes.default.svc.cluster.local",
            "Port": 443,
            "AppSettingsToken": ""
          }
        },
        "Resources": {
          "KubernetesApiVersionResource": {
            "Version": "1.19.6",
            "Binding": {
              "Name": "bindings",
              "ShortNames": "",
              "APIGroup": "",
              "IsNamespaced": true,
              "Version": "v1"
            },
            "ComponentStatus": {
              "Name": "componentstatuses",
              "ShortNames": "cs",
              "APIGroup": "",
              "IsNamespaced": false,
              "Version": "v1"
            },
            "ConfigMap": {
              "Name": "configmaps",
              "ShortNames": "cm",
              "APIGroup": "",
              "IsNamespaced": true,
              "Version": "v1"
            },
            "Endpoints": {
              "Name": "endpoints",
              "ShortNames": "ep",
              "APIGroup": "",
              "IsNamespaced": true,
              "Version": "v1"
            },
            "Event": {
              "Name": "events",
              "ShortNames": "ev",
              "APIGroup": "",
              "IsNamespaced": true,
              "Version": "v1"
            },
            "LimitRange": {
              "Name": "limitranges",
              "ShortNames": "limits",
              "APIGroup": "",
              "IsNamespaced": true,
              "Version": "v1"
            },
            "Namespace": {
              "Name": "namespaces",
              "ShortNames": "ns",
              "APIGroup": "",
              "IsNamespaced": false,
              "Version": "v1"
            },
            "Node": {
              "Name": "nodes",
              "ShortNames": "no",
              "APIGroup": "",
              "IsNamespaced": false,
              "Version": "v1"
            },
            "PersistentVolumeClaim": {
              "Name": "persistentvolumeclaims",
              "ShortNames": "pvc",
              "APIGroup": "",
              "IsNamespaced": true,
              "Version": "v1"
            },
            "PersistentVolume": {
              "Name": "persistentvolumes",
              "ShortNames": "pv",
              "APIGroup": "",
              "IsNamespaced": false,
              "Version": "v1"
            },
            "Pod": {
              "Name": "pods",
              "ShortNames": "po",
              "APIGroup": "",
              "IsNamespaced": true,
              "Version": "v1"
            },
            "PodTemplate": {
              "Name": "podtemplates",
              "ShortNames": "",
              "APIGroup": "",
              "IsNamespaced": true,
              "Version": "v1"
            },
            "ReplicationController": {
              "Name": "replicationcontrollers",
              "ShortNames": "rc",
              "APIGroup": "",
              "IsNamespaced": true,
              "Version": "v1"
            },
            "ResourceQuota": {
              "Name": "resourcequotas",
              "ShortNames": "quota",
              "APIGroup": "",
              "IsNamespaced": true,
              "Version": "v1"
            },
            "Secret": {
              "Name": "secrets",
              "ShortNames": "",
              "APIGroup": "",
              "IsNamespaced": true,
              "Version": "v1"
            },
            "ServiceAccount": {
              "Name": "serviceaccounts",
              "ShortNames": "sa",
              "APIGroup": "",
              "IsNamespaced": true,
              "Version": "v1"
            },
            "Service": {
              "Name": "services",
              "ShortNames": "svc",
              "APIGroup": "",
              "IsNamespaced": true,
              "Version": "v1"
            },
            "MutatingWebhookConfiguration": {
              "Name": "mutatingwebhookconfigurations",
              "ShortNames": "",
              "APIGroup": "admissionregistration.k8s.io",
              "IsNamespaced": false,
              "Version": "admissionregistration.k8s.io/v1"
            },
            "ValidatingWebhookConfiguration": {
              "Name": "validatingwebhookconfigurations",
              "ShortNames": "",
              "APIGroup": "admissionregistration.k8s.io",
              "IsNamespaced": false,
              "Version": "admissionregistration.k8s.io/v1"
            },
            "CustomResourceDefinition": {
              "Name": "customresourcedefinitions",
              "ShortNames": "crd,crds",
              "APIGroup": "apiextensions.k8s.io",
              "IsNamespaced": false,
              "Version": "apiextensions.k8s.io/v1"
            },
            "APIService": {
              "Name": "apiservices",
              "ShortNames": "",
              "APIGroup": "apiregistration.k8s.io ",
              "IsNamespaced": false,
              "Version": "apiregistration.k8s.io/v1"
            },
            "ControllerRevision": {
              "Name": "controllerrevisions",
              "ShortNames": "",
              "APIGroup": "apps",
              "IsNamespaced": true,
              "Version": "apps/v1"
            },
            "DaemonSet": {
              "Name": "daemonsets",
              "ShortNames": "ds",
              "APIGroup": "apps",
              "IsNamespaced": true,
              "Version": "apps/v1"
            },
            "Deployment": {
              "Name": "deployments",
              "ShortNames": "deploy",
              "APIGroup": "",
              "IsNamespaced": true,
              "Version": "apps/v1"
            },
            "ReplicaSet": {
              "Name": "replicasets",
              "ShortNames": "rs",
              "APIGroup": "apps",
              "IsNamespaced": true,
              "Version": "apps/v1"
            },
            "StatefulSet": {
              "Name": "statefulsets",
              "ShortNames": "sts",
              "APIGroup": "apps",
              "IsNamespaced": true,
              "Version": "apps/v1"
            },
            "TokenReview": {
              "Name": "tokenreviews",
              "ShortNames": "",
              "APIGroup": "authentication.k8s.io",
              "IsNamespaced": false,
              "Version": "authentication.k8s.io/v1"
            },
            "LocalSubjectAccessReview": {
              "Name": "localsubjectaccessreviews",
              "ShortNames": "",
              "APIGroup": "authorization.k8s.io",
              "IsNamespaced": true,
              "Version": "authorization.k8s.io/v1"
            },
            "SelfSubjectAccessReview": {
              "Name": "selfsubjectaccessreviews",
              "ShortNames": "",
              "APIGroup": "authorization.k8s.io",
              "IsNamespaced": false,
              "Version": "authorization.k8s.io/v1"
            },
            "SelfSubjectRulesReview": {
              "Name": "selfsubjectrulesreviews",
              "ShortNames": "",
              "APIGroup": "authorization.k8s.io",
              "IsNamespaced": true,
              "Version": "authorization.k8s.io/v1"
            },
            "SubjectAccessReview": {
              "Name": "subjectaccessreviews",
              "ShortNames": "",
              "APIGroup": "authorization.k8s.io",
              "IsNamespaced": false,
              "Version": "authorization.k8s.io/v1"
            },
            "HorizontalPodAutoscaler": {
              "Name": "horizontalpodautoscalers",
              "ShortNames": "hpa",
              "APIGroup": "autoscaling",
              "IsNamespaced": true,
              "Version": "autoscaling/v1"
            },
            "CronJob": {
              "Name": "cronjobs",
              "ShortNames": "cj",
              "APIGroup": "batch",
              "IsNamespaced": true,
              "Version": "batch/v1beta1"
            },
            "Job": {
              "Name": "jobs",
              "ShortNames": "",
              "APIGroup": "batch",
              "IsNamespaced": true,
              "Version": "batch/v1"
            },
            "CertificateSigningRequest": {
              "Name": "certificatesigningrequests",
              "ShortNames": "csr",
              "APIGroup": "certificates.k8s.io",
              "IsNamespaced": false,
              "Version": "certificates.k8s.io/v1beta1"
            },
            "Lease": {
              "Name": "leases",
              "ShortNames": "",
              "APIGroup": "coordination.k8s.io",
              "IsNamespaced": true,
              "Version": "coordination.k8s.io/v1"
            },
            "BGPConfiguration": {
              "Name": "bgpconfigurations",
              "ShortNames": "",
              "APIGroup": "crd.projectcalico.org",
              "IsNamespaced": false,
              "Version": "crd.projectcalico.org/v1"
            },
            "BGPPeer": {
              "Name": "bgppeers",
              "ShortNames": "",
              "APIGroup": "crd.projectcalico.org",
              "IsNamespaced": false,
              "Version": "crd.projectcalico.org/v1"
            },
            "BlockAffinity": {
              "Name": "blockaffinities",
              "ShortNames": "",
              "APIGroup": "crd.projectcalico.org",
              "IsNamespaced": false,
              "Version": "crd.projectcalico.org/v1"
            },
            "ClusterInformation": {
              "Name": "clusterinformations",
              "ShortNames": "",
              "APIGroup": "crd.projectcalico.org",
              "IsNamespaced": false,
              "Version": "crd.projectcalico.org/v1"
            },
            "FelixConfiguration": {
              "Name": "felixconfigurations",
              "ShortNames": "",
              "APIGroup": "crd.projectcalico.org",
              "IsNamespaced": false,
              "Version": "crd.projectcalico.org/v1"
            },
            "GlobalNetworkPolicy": {
              "Name": "globalnetworkpolicies",
              "ShortNames": "gnp",
              "APIGroup": "crd.projectcalico.org",
              "IsNamespaced": false,
              "Version": "crd.projectcalico.org/v1"
            },
            "GlobalNetworkSet": {
              "Name": "globalnetworksets",
              "ShortNames": "",
              "APIGroup": "crd.projectcalico.org",
              "IsNamespaced": false,
              "Version": "crd.projectcalico.org/v1"
            },
            "HostEndpoint": {
              "Name": "hostendpoints",
              "ShortNames": "",
              "APIGroup": "crd.projectcalico.org",
              "IsNamespaced": false,
              "Version": "crd.projectcalico.org/v1"
            },
            "IPAMBlock": {
              "Name": "ipamblocks",
              "ShortNames": "crd.projectcalico.org",
              "APIGroup": "",
              "IsNamespaced": false,
              "Version": "crd.projectcalico.org/v1"
            },
            "IPAMConfig": {
              "Name": "ipamconfigs",
              "ShortNames": "",
              "APIGroup": "crd.projectcalico.org",
              "IsNamespaced": false,
              "Version": "crd.projectcalico.org/v1"
            },
            "IPAMHandle": {
              "Name": "ipamhandles",
              "ShortNames": "",
              "APIGroup": "crd.projectcalico.org",
              "IsNamespaced": false,
              "Version": "crd.projectcalico.org/v1"
            },
            "IPPool": {
              "Name": "ippools",
              "ShortNames": "",
              "APIGroup": "crd.projectcalico.org",
              "IsNamespaced": false,
              "Version": "crd.projectcalico.org/v1"
            },
            "KubeControllersConfiguration": {
              "Name": "kubecontrollersconfigurations",
              "ShortNames": "",
              "APIGroup": "crd.projectcalico.org",
              "IsNamespaced": false,
              "Version": "crd.projectcalico.org/v1"
            },
            "NetworkPolicy": {
              "Name": "networkpolicies",
              "ShortNames": "",
              "APIGroup": "crd.projectcalico.org",
              "IsNamespaced": true,
              "Version": "crd.projectcalico.org/v1"
            },
            "NetworkSet": {
              "Name": "networksets",
              "ShortNames": "",
              "APIGroup": "crd.projectcalico.org",
              "IsNamespaced": true,
              "Version": "crd.projectcalico.org/v1"
            },
            "EndpointSlice": {
              "Name": "endpointslices",
              "ShortNames": "",
              "APIGroup": "discovery.k8s.io",
              "IsNamespaced": true,
              "Version": "discovery.k8s.io/v1"
            },
            "Event_K8S": {
              "Name": "events",
              "ShortNames": "ev",
              "APIGroup": "events.k8s.io",
              "IsNamespaced": true,
              "Version": "events.k8s.io/v1beta1"
            },
            "Ingress": {
              "Name": "ingresses",
              "ShortNames": "ing",
              "APIGroup": "extensions",
              "IsNamespaced": true,
              "Version": "extensions/v1beta1"
            },
            "IngressClass": {
              "Name": "ingressclasses",
              "ShortNames": "networking.k8s.io",
              "APIGroup": "",
              "IsNamespaced": false,
              "Version": "networking.k8s.io/v1beta1"
            },
            "Ingress_K8S": {
              "Name": "ingresses",
              "ShortNames": "ing",
              "APIGroup": "networking.k8s.io",
              "IsNamespaced": true,
              "Version": "networking.k8s.io/v1beta1"
            },
            "NetworkPolicy_K8S": {
              "Name": "networkpolicies",
              "ShortNames": "netpol",
              "APIGroup": "networking.k8s.io",
              "IsNamespaced": true,
              "Version": "networking.k8s.io/v1beta1"
            },
            "RuntimeClass": {
              "Name": "runtimeclasses",
              "ShortNames": "",
              "APIGroup": "node.k8s.io",
              "IsNamespaced": false,
              "Version": "node.k8s.io/v1beta1"
            },
            "PodDisruptionBudget": {
              "Name": "poddisruptionbudgets",
              "ShortNames": "pdb",
              "APIGroup": "policy",
              "IsNamespaced": true,
              "Version": "policy/v1beta1"
            },
            "PodSecurityPolicy": {
              "Name": "podsecuritypolicies",
              "ShortNames": "psp",
              "APIGroup": "policy",
              "IsNamespaced": false,
              "Version": "policy/v1beta1"
            },
            "ClusterRoleBinding": {
              "Name": "clusterrolebindings",
              "ShortNames": "",
              "APIGroup": "rbac.authorization.k8s.io",
              "IsNamespaced": false,
              "Version": "rbac.authorization.k8s.io/v1"
            },
            "ClusterRole": {
              "Name": "clusterroles",
              "ShortNames": "",
              "APIGroup": "rbac.authorization.k8s.io",
              "IsNamespaced": false,
              "Version": "rbac.authorization.k8s.io/v1"
            },
            "RoleBinding": {
              "Name": "rolebindings",
              "ShortNames": "",
              "APIGroup": "rbac.authorization.k8s.io",
              "IsNamespaced": true,
              "Version": "rbac.authorization.k8s.io/v1"
            },
            "Role": {
              "Name": "roles",
              "ShortNames": "",
              "APIGroup": "rbac.authorization.k8s.io",
              "IsNamespaced": true,
              "Version": "rbac.authorization.k8s.io/v1"
            },
            "PriorityClass": {
              "Name": "priorityclasses",
              "ShortNames": "pc",
              "APIGroup": "scheduling.k8s.io",
              "IsNamespaced": false,
              "Version": "scheduling.k8s.io/v1"
            },
            "CSIDriver": {
              "Name": "csidrivers",
              "ShortNames": "",
              "APIGroup": "storage.k8s.io",
              "IsNamespaced": false,
              "Version": "storage.k8s.io/v1"
            },
            "CSINode": {
              "Name": "csinodes",
              "ShortNames": "",
              "APIGroup": "storage.k8s.io",
              "IsNamespaced": false,
              "Version": "storage.k8s.io/v1"
            },
            "StorageClass": {
              "Name": "storageclasses",
              "ShortNames": "",
              "APIGroup": "storage.k8s.io",
              "IsNamespaced": false,
              "Version": "storage.k8s.io/v1"
            },
            "VolumeAttachment": {
              "Name": "volumeattachments",
              "ShortNames": "",
              "APIGroup": "storage.k8s.io",
              "IsNamespaced": false,
              "Version": "storage.k8s.io/v1"
            },
            "NodeMetrics": {
              "Name": "nodes",
              "ShortNames": "",
              "APIGroup": "metrics.k8s.io",
              "IsNamespaced": false,
              "Version": "metrics.k8s.io/v1beta1"
            },
            "PodMetrics": {
              "Name": "pods",
              "ShortNames": "",
              "APIGroup": "metrics.k8s.io",
              "IsNamespaced": false,
              "Version": "metrics.k8s.io/v1beta1"
            }
          },
          "IstioApiVersionResource": {
            "Version": "1.6.2",
            "DestinationRule": {
              "Name": "destinationrules",
              "ShortNames": "dr",
              "APIGroup": "networking.istio.io",
              "IsNamespaced": false,
              "Version": "networking.istio.io/v1beta1"
            },
            "Gateway": {
              "Name": "gateways",
              "ShortNames": "gw",
              "APIGroup": "networking.istio.io",
              "IsNamespaced": true,
              "Version": "networking.istio.io/v1beta1"
            },
            "ServiceEntry": {
              "Name": "serviceentries",
              "ShortNames": "se",
              "APIGroup": "networking.istio.io",
              "IsNamespaced": false,
              "Version": "networking.istio.io/v1beta1"
            },
            "Sidecar": {
              "Name": "sidecars",
              "ShortNames": "sc",
              "APIGroup": "networking.istio.io",
              "IsNamespaced": true,
              "Version": "networking.istio.io/v1beta1"
            },
            "VirtualService": {
              "Name": "virtualservices",
              "ShortNames": "vs",
              "APIGroup": "networking.istio.io",
              "IsNamespaced": false,
              "Version": "networking.istio.io/v1beta1"
            },
            "EnvoyFilter": {
              "Name": "envoyfilters",
              "ShortNames": "",
              "APIGroup": "networking.istio.io",
              "IsNamespaced": false,
              "Version": "networking.istio.io/v1alpha3"
            },
            "WorkloadEntry": {
              "Name": "workloadentries",
              "ShortNames": "",
              "APIGroup": "networking.istio.io",
              "IsNamespaced": false,
              "Version": "networking.istio.io/v1beta1"
            }
          },
          "FewBoxApiVersionResource": {
            "PackingTable": {
              "Name": "packingtables",
              "ShortNames": "pt",
              "APIGroup": "fewbox.com",
              "IsNamespaced": true,
              "Version": "fewbox.com/v1"
            },
            "Kit": {
              "Name": "kits",
              "ShortNames": "k",
              "APIGroup": "fewbox.com",
              "IsNamespaced": false,
              "Version": "fewbox.com/v1"
            }
          },
          "ThirdPartApiVersionResource": {
            "RabbitMQ": {
              "Name": "rabbitmqclusters",
              "ShortNames": "rmq",
              "APIGroup": "rabbitmq.com",
              "IsNamespaced": true,
              "Version": "rabbitmq.com/v1beta1"
            },
            "ClusterKopfPeering": {
              "Name": "clusterkopfpeerings",
              "ShortNames": "",
              "APIGroup": "zalando.org",
              "IsNamespaced": false,
              "Version": "zalando.org/v1"
            },
            "KopfPeering": {
              "Name": "kopfpeerings",
              "ShortNames": "",
              "APIGroup": "zalando.org",
              "IsNamespaced": true,
              "Version": "zalando.org/v1"
            },
            "MySQLBackup": {
              "Name": "mysqlbackups",
              "ShortNames": "",
              "APIGroup": "mysql.oracle.com",
              "IsNamespaced": true,
              "Version": "mysql.oracle.com/v2"
            },
            "InnoDBCluster": {
              "Name": "innodbclusters",
              "ShortNames": "ic,ics",
              "APIGroup": "mysql.oracle.com",
              "IsNamespaced": true,
              "Version": "mysql.oracle.com/v2"
            }
          }
        },
        "Storages": {
          "NFS": {
            "Server": "$NFSSERVER",
            "Path": "$NFSPATH"
          }
        }
      }
    }
---
# FewBox PackingTable Engine
apiVersion: apps/v1
kind: Deployment
metadata:
  annotations:
    brand: fewbox
  labels:
    brand: fewbox
  name: packingtable
  namespace: $NAMESPACE
spec:
  progressDeadlineSeconds: 600
  replicas: 1
  selector:
    matchLabels:
      app: packingtable
  template:
    metadata:
      annotations:
        brand: fewbox
      creationTimestamp: null
      labels:
        brand: fewbox
        app: packingtable
    spec:
      automountServiceAccountToken: true
      containers:
      - image: $PACKINGTABLEIMAGE
        imagePullPolicy: IfNotPresent
        name: packingtable
        volumeMounts:
        - mountPath: /app/appsettings.json
          name: packingtable
          readOnly: true
          subPath: packingtable
      dnsPolicy: ClusterFirst
      restartPolicy: Always
      serviceAccount: fewbox
      serviceAccountName: fewbox
      volumes:
      - configMap:
          defaultMode: 420
          name: packingtable
        name: packingtable
---
# FewBox PackingTable CRD
apiVersion: apiextensions.k8s.io/v1
kind: CustomResourceDefinition
metadata:
  annotations:
    brand: fewbox
  labels:
    brand: fewbox
    tenant: $NAMESPACE
  name: packingtables.fewbox.com
spec:
  # group name to use for REST API: /apis/<group>/<version>
  # /apis/fewbox.com/v1
  group: fewbox.com
  # list of versions supported by this CustomResourceDefinition
  versions:
    - name: v1
      # Each version can be enabled/disabled by Served flag.
      served: true
      # One and only one version must be marked as the storage version.
      storage: true
      schema:
        openAPIV3Schema:
          type: object
          properties:
            spec:
              type: object
              properties:
                logo:
                  type: string
                registry:
                  type: string
                type:
                  description: 'infrastructure: NFS storage; thirdparty: rabbitmq, verdaccio; foundation: auth, mail, payment, realtime, shipping, tape; pack: other.'
                  type: string
                solution:
                  type: string
                domain:
                  type: string
                packs:
                  type: array
                  items:
                    type: object
                    properties:
                      settingsTemplate:
                        type: string
                      settingsVariables:
                        type: object
                        additionalProperties:
                          type: string
                      registry:
                        type: string
                      repository:
                        type: string
                      app:
                        type: string
                      version:
                        type: string
                      replica:
                        type: integer
                      isIgnore:
                        type: boolean
                      isPublic:
                        type: boolean
                      isRunAsClusterAdmin:
                        type: boolean
                customPacks:
                  type: array
                  items:
                    type: object
                    properties:
                      registry:
                        type: string
                      repository:
                        type: string
                      app:
                        type: string
                      version:
                        type: string
                      replica:
                        type: integer
                      isIgnore:
                        type: boolean
                      isPublic:
                        type: boolean
                      isRunAsClusterAdmin:
                        type: boolean
                      settings:
                        type: array
                        items:
                          type: object
                          properties:
                            name:
                              type: string
                            path:
                              type: string
                            settingsTemplate:
                              type: string
                            settingsVariables:
                              type: object
                              additionalProperties:
                                type: string
                taskPacks:
                  type: array
                  items:
                    type: object
                    properties:
                      isSkipSidecar:
                        type: boolean
                      registry:
                        type: string
                      repository:
                        type: string
                      app:
                        type: string
                      version:
                        type: string
                      isIgnore:
                        type: boolean
                      settingsTemplate:
                        type: string
                      settingsVariables:
                        type: object
                        additionalProperties:
                          type: string
                customTaskPacks:
                  type: array
                  items:
                    type: object
                    properties:
                      isSkipSidecar:
                        type: boolean
                      registry:
                        type: string
                      repository:
                        type: string
                      app:
                        type: string
                      version:
                        type: string
                      isIgnore:
                        type: boolean
                      settings:
                        type: array
                        items:
                          type: object
                          properties:
                            name:
                              type: string
                            path:
                              type: string
                            settingsTemplate:
                              type: string
                            settingsVariables:
                              type: object
                              additionalProperties:
                                type: string
                scheduledTaskPacks:
                  type: array
                  items:
                    type: object
                    properties:
                      isSkipSidecar:
                        type: boolean
                      registry:
                        type: string
                      repository:
                        type: string
                      app:
                        type: string
                      version:
                        type: string
                      isIgnore:
                        type: boolean
                      schedule:
                        type: string
                      settingsTemplate:
                        type: string
                      settingsVariables:
                        type: object
                        additionalProperties:
                          type: string
                customScheduledTaskPacks:
                  type: array
                  items:
                    type: object
                    properties:
                      isSkipSidecar:
                        type: boolean
                      registry:
                        type: string
                      repository:
                        type: string
                      app:
                        type: string
                      version:
                        type: string
                      isIgnore:
                        type: boolean
                      schedule:
                        type: string
                      settings:
                        type: array
                        items:
                          type: object
                          properties:
                            name:
                              type: string
                            path:
                              type: string
                            settingsTemplate:
                              type: string
                            settingsVariables:
                              type: object
                              additionalProperties:
                                type: string
                thirdParty:
                  type: object
                  properties:
                    registry:
                        type: string
                    rabbitMQSettingsTemplate:
                      type: string
                    rabbitMQSettingsVariables:
                      type: object
                      additionalProperties:
                        type: string
                    rabbitMQVersion:
                      type: string
                    rabbitMQOperatorVersion:
                      type: string
                    rabbitMQPassword:
                      type: string
                    rabbitMQCRD:
                      type: string
                    rabbitMQStorage:
                      type: string
                    verdaccioSettingsTemplate:
                      type: string
                    verdaccioSettingsVariables:
                      type: object
                      additionalProperties:
                        type: string
                    verdaccioVersion:
                      type: string
                    verdaccioStorage:
                      type: string
                    mySQLVersion:
                      type: string
                    mySQLOperatorVersion:
                      type: string
                    mySQLInnoDBClustersCRD:
                      type: string
                    mysqlBackupsCRD:
                      type: string
                    mySQLClusterKopfPeeringsCRD:
                      type: string
                    mySQLKopfPeeringsCRD:
                      type: string
                    mySQLStorage:
                      type: string
                    mySQLPassword:
                      type: string
                    mySQLTlsUseSelfSigned:
                      type: boolean
                    mySQLInstances:
                      type: integer
                    mySQLRouterInstances:
                      type: integer
                    redisSettingsTemplate:
                      type: string
                    redisSettingsVariables:
                      type: object
                      additionalProperties:
                        type: string
                    redisVersion:
                      type: string
                    redisStorage:
                      type: string
  # either Namespaced or Cluster
  scope: Namespaced
  names:
    # plural name to be used in the URL: /apis/<group>/<version>/<plural>
    # /apis/fewbox.com/v1/packingtables
    plural: packingtables
    # singular name to be used as an alias on the CLI and for display
    singular: packingtable
    # kind is normally the CamelCased singular type. Your resource manifests use this.
    kind: PackingTable
    # shortNames allow shorter string to match your resource on the CLI
    shortNames:
    - pt
# FewBox Kit CRD
apiVersion: apiextensions.k8s.io/v1
kind: CustomResourceDefinition
metadata:
  annotations:
    brand: fewbox
  labels:
    brand: fewbox
    tenant: $NAMESPACE
  name: kits.fewbox.com
spec:
  # group name to use for REST API: /apis/<group>/<version>
  # /apis/fewbox.com/v1
  group: fewbox.com
  # list of versions supported by this CustomResourceDefinition
  versions:
    - name: v1
      # Each version can be enabled/disabled by Served flag.
      served: true
      # One and only one version must be marked as the storage version.
      storage: true
      schema:
        openAPIV3Schema:
          type: object
          properties:
            spec:
              type: object
              properties:
                logo:
                  type: string
                poweredBy:
                  type: string
                cpuLimit:
                  type: string
                memoryLimit:
                  type: string
                packingTable:
                  type: object
  # either Namespaced or Cluster
  scope: Cluster
  names:
    # plural name to be used in the URL: /apis/<group>/<version>/<plural>
    # /apis/fewbox.com/v1/kits
    plural: kits
    # singular name to be used as an alias on the CLI and for display
    singular: kit
    # kind is normally the CamelCased singular type. Your resource manifests use this.
    kind: Kit
    # shortNames allow shorter string to match your resource on the CLI
    shortNames:
    - k
EOF
